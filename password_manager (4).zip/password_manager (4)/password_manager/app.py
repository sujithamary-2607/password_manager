from flask import Flask, request, session, jsonify, send_file, redirect
import sqlite3
import cv2
import numpy as np
import base64
from werkzeug.security import generate_password_hash, check_password_hash
from contextlib import contextmanager
import os
from datetime import datetime
import io

app = Flask(__name__)
app.secret_key = "secure_vault_secret_key_2024"
DB_FILE = "password_manager.db"

# Database setup
@contextmanager
def get_connection():
    conn = None
    try:
        conn = sqlite3.connect(DB_FILE, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        yield conn
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        if conn:
            conn.rollback()
        raise
    finally:
        if conn:
            conn.close()

def init_db():
    with get_connection() as conn:
        c = conn.cursor()
        
        # Drop tables if they exist
        c.execute("DROP TABLE IF EXISTS password_hashes")
        c.execute("DROP TABLE IF EXISTS security_logs") 
        c.execute("DROP TABLE IF EXISTS credentials")
        c.execute("DROP TABLE IF EXISTS users")
        
        # Create tables
        c.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT,
            face_image BLOB,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME
        )""")
        
        c.execute("""
        CREATE TABLE credentials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            site TEXT NOT NULL,
            site_username TEXT NOT NULL,
            site_password TEXT NOT NULL,
            category TEXT DEFAULT 'Other',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )""")
        
        c.execute("""
        CREATE TABLE security_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            details TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )""")
        
        conn.commit()
        print("✅ Database created successfully!")

# Security logging
def log_security_action(user_id, action, details=None):
    try:
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("""
                INSERT INTO security_logs (user_id, action, ip_address, user_agent, details) 
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, action, request.remote_addr, 
                  request.headers.get('User-Agent'), details))
            conn.commit()
    except Exception as e:
        print(f"Error logging security action: {e}")

# Face recognition functions
def process_face_image(face_data):
    try:
        if ',' in face_data:
            face_data = face_data.split(',')[1]
        
        face_bytes = base64.b64decode(face_data)
        img = cv2.imdecode(np.frombuffer(face_bytes, np.uint8), cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Invalid image data")
        
        # Detect face first
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        
        if len(faces) == 0:
            raise ValueError("No face detected in the image")
        
        # Crop and resize face
        x, y, w, h = faces[0]
        face_roi = img[y:y+h, x:x+w]
        face_roi = cv2.resize(face_roi, (224, 224))
        
        success, encoded_img = cv2.imencode('.jpg', face_roi, [cv2.IMWRITE_JPEG_QUALITY, 90])
        if success:
            return encoded_img.tobytes()
        else:
            raise ValueError("Failed to encode image")
            
    except Exception as e:
        print(f"Face processing error: {e}")
        raise

def verify_face(input_face_data, stored_face_bytes):
    try:
        if not stored_face_bytes:
            return False
            
        # Process input image
        if ',' in input_face_data:
            input_face_data = input_face_data.split(',')[1]
        
        input_bytes = base64.b64decode(input_face_data)
        input_img = cv2.imdecode(np.frombuffer(input_bytes, np.uint8), cv2.IMREAD_COLOR)
        
        if input_img is None:
            return False
        
        # Process stored image
        stored_img = cv2.imdecode(np.frombuffer(stored_face_bytes, np.uint8), cv2.IMREAD_COLOR)
        
        if stored_img is None:
            return False
        
        # Convert to grayscale for face detection
        gray_input = cv2.cvtColor(input_img, cv2.COLOR_BGR2GRAY)
        gray_stored = cv2.cvtColor(stored_img, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        faces_input = face_cascade.detectMultiScale(gray_input, 1.1, 4)
        faces_stored = face_cascade.detectMultiScale(gray_stored, 1.1, 4)
        
        if len(faces_input) == 0 or len(faces_stored) == 0:
            return False
        
        # Extract face regions
        x1, y1, w1, h1 = faces_input[0]
        x2, y2, w2, h2 = faces_stored[0]
        
        face_input = input_img[y1:y1+h1, x1:x1+w1]
        face_stored = stored_img[y2:y2+h2, x2:x2+w2]
        
        # Resize to same dimensions
        face_input = cv2.resize(face_input, (100, 100))
        face_stored = cv2.resize(face_stored, (100, 100))
        
        # Convert to HSV for better color comparison
        hsv_input = cv2.cvtColor(face_input, cv2.COLOR_BGR2HSV)
        hsv_stored = cv2.cvtColor(face_stored, cv2.COLOR_BGR2HSV)
        
        # Calculate histogram and compare
        hist_input = cv2.calcHist([hsv_input], [0, 1], None, [50, 60], [0, 180, 0, 256])
        hist_stored = cv2.calcHist([hsv_stored], [0, 1], None, [50, 60], [0, 180, 0, 256])
        
        cv2.normalize(hist_input, hist_input, 0, 1, cv2.NORM_MINMAX)
        cv2.normalize(hist_stored, hist_stored, 0, 1, cv2.NORM_MINMAX)
        
        # Compare histograms
        similarity = cv2.compareHist(hist_input, hist_stored, cv2.HISTCMP_CORREL)
        
        print(f"Face similarity score: {similarity}")
        
        # Use a threshold for face matching - lowered for better demo experience
        return similarity > 0.3  # Lower threshold for demo
        
    except Exception as e:
        print(f"Face verification error: {e}")
        return False

# Password strength
def check_password_strength(password):
    if len(password) < 8:
        return "very_weak"
    elif len(password) < 12:
        return "weak"
    
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(not c.isalnum() for c in password)
    
    score = sum([has_upper, has_lower, has_digit, has_special])
    
    if len(password) >= 16 and score >= 3:
        return "very_strong"
    elif len(password) >= 12 and score >= 3:
        return "strong"
    elif score >= 2:
        return "moderate"
    else:
        return "weak"

# Routes for pages
@app.route('/')
def index():
    return send_file('index.html')

@app.route('/login')
def login_page():
    return send_file('login.html')

@app.route('/register')
def register_page():
    return send_file('register.html')

@app.route('/dashboard')
def dashboard_page():
    if "user_id" not in session:
        return redirect('/login')
    return send_file('dashboard.html')

@app.route('/passwords')
def passwords_page():
    if "user_id" not in session:
        return redirect('/login')
    return send_file('passwords.html')

@app.route('/generator')
def generator_page():
    if "user_id" not in session:
        return redirect('/login')
    return send_file('generator.html')

@app.route('/profile')
def profile_page():
    if "user_id" not in session:
        return redirect('/login')
    return send_file('profile.html')

@app.route('/about')
def about_page():
    if "user_id" not in session:
        return redirect('/login')
    return send_file('about.html')

# API Routes
@app.route('/api/check-auth', methods=['GET'])
def check_auth():
    if "user_id" in session:
        try:
            with get_connection() as conn:
                c = conn.cursor()
                c.execute("SELECT email FROM users WHERE id=?", (session['user_id'],))
                user = c.fetchone()
                if user:
                    return jsonify({
                        "authenticated": True, 
                        "user_id": session["user_id"],
                        "email": user[0]
                    })
        except Exception as e:
            print(f"Auth check error: {e}")
    
    return jsonify({"authenticated": False})

@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "message": "No data provided"}), 400
        
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')
        face_data = data.get('face_data')
        
        if not email or '@' not in email:
            return jsonify({"success": False, "message": "Valid email is required"}), 400
        
        if not password:
            return jsonify({"success": False, "message": "Password is required"}), 400
        
        if not face_data:
            return jsonify({"success": False, "message": "Face recognition data is required"}), 400
        
        password_strength = check_password_strength(password)
        if password_strength in ['weak', 'very_weak']:
            return jsonify({"success": False, "message": "Password is too weak"}), 400
        
        try:
            # Process face image
            face_image_blob = process_face_image(face_data)
            
            with get_connection() as conn:
                c = conn.cursor()
                c.execute("SELECT id FROM users WHERE email=?", (email,))
                if c.fetchone():
                    return jsonify({"success": False, "message": "Email already registered"}), 400
                
                password_hash = generate_password_hash(password)
                
                c.execute("INSERT INTO users (email, password_hash, face_image) VALUES (?, ?, ?)", 
                         (email, password_hash, face_image_blob))
                user_id = c.lastrowid
                conn.commit()
                
                log_security_action(user_id, "REGISTER", "User registered with face data")
                
                return jsonify({
                    "success": True, 
                    "message": "Registered successfully!",
                    "user_id": user_id
                })
                
        except ValueError as e:
            error_msg = str(e)
            if "No face detected" in error_msg:
                return jsonify({"success": False, "message": "No face detected in the image. Please ensure your face is clearly visible."}), 400
            else:
                return jsonify({"success": False, "message": f"Face processing error: {error_msg}"}), 400
        except sqlite3.IntegrityError:
            return jsonify({"success": False, "message": "Email already registered"}), 400
            
    except Exception as e:
        print(f"Registration error: {e}")
        return jsonify({"success": False, "message": f"Registration failed: {str(e)}"}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "message": "No data provided"}), 400
        
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')
        face_data = data.get('face_data')
        
        if not email:
            return jsonify({"success": False, "message": "Email is required"}), 400
        
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT id, password_hash, face_image FROM users WHERE email=?", (email,))
            user = c.fetchone()
            
            if not user:
                return jsonify({"success": False, "message": "User not found"}), 404
            
            user_id, password_hash, stored_face = user
            
            # Update last login
            c.execute("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id=?", (user_id,))
            conn.commit()
            
            # Password login
            if password:
                if password_hash and check_password_hash(password_hash, password):
                    session["user_id"] = user_id
                    log_security_action(user_id, "LOGIN_PASSWORD", "Password login successful")
                    return jsonify({
                        "success": True, 
                        "message": "Login successful!",
                        "user_id": user_id
                    })
                else:
                    log_security_action(user_id, "LOGIN_PASSWORD_FAILED", "Incorrect password")
                    return jsonify({"success": False, "message": "Incorrect password"}), 401
            
            # Face recognition login
            if face_data:
                if stored_face:
                    try:
                        if verify_face(face_data, stored_face):
                            session["user_id"] = user_id
                            log_security_action(user_id, "LOGIN_FACE", "Face recognition successful")
                            return jsonify({
                                "success": True, 
                                "message": "Face recognition successful!",
                                "user_id": user_id
                            })
                        else:
                            log_security_action(user_id, "LOGIN_FACE_FAILED", "Face verification failed")
                            return jsonify({"success": False, "message": "Face verification failed. Please try again or use password."}), 401
                    except Exception as e:
                        log_security_action(user_id, "LOGIN_FACE_ERROR", f"Face processing error: {str(e)}")
                        return jsonify({"success": False, "message": "Error processing face data. Please try again."}), 400
                else:
                    return jsonify({"success": False, "message": "Face recognition not set up for this account"}), 401
            
            return jsonify({"success": False, "message": "Please provide password or face data"}), 401
                
    except Exception as e:
        print(f"Login error: {e}")
        return jsonify({"success": False, "message": f"Login failed: {str(e)}"}), 500

@app.route('/api/dashboard/stats', methods=['GET'])
def dashboard_stats():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    try:
        with get_connection() as conn:
            c = conn.cursor()
            
            # Get total passwords count
            c.execute("SELECT COUNT(*) FROM credentials WHERE user_id=?", (session['user_id'],))
            total_passwords = c.fetchone()[0]
            
            # Get all passwords for strength analysis
            c.execute("SELECT site_password FROM credentials WHERE user_id=?", (session['user_id'],))
            passwords = [row[0] for row in c.fetchall()]
            
            # Calculate password strength breakdown
            strength_counts = {
                "very_strong": 0, 
                "strong": 0, 
                "moderate": 0, 
                "weak": 0, 
                "very_weak": 0
            }
            
            for password in passwords:
                strength = check_password_strength(password)
                strength_counts[strength] += 1
            
            strong_passwords = strength_counts["strong"] + strength_counts["very_strong"]
            weak_passwords = strength_counts["weak"] + strength_counts["very_weak"]
            
            # Calculate reused passwords (simple check)
            reused_passwords = len(passwords) - len(set(passwords))
            
            return jsonify({
                "success": True, 
                "stats": {
                    "total_passwords": total_passwords,
                    "strong_passwords": strong_passwords,
                    "weak_passwords": weak_passwords,
                    "reused_passwords": max(0, reused_passwords),
                    "strength_breakdown": strength_counts
                }
            })
    except Exception as e:
        print(f"Dashboard stats error: {e}")
        return jsonify({"success": False, "message": f"Failed to get stats: {str(e)}"}), 500

@app.route('/api/credentials', methods=['GET', 'POST'])
def manage_credentials():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    if request.method == 'GET':
        try:
            with get_connection() as conn:
                c = conn.cursor()
                c.execute("""
                    SELECT id, site, site_username, site_password, category, created_at 
                    FROM credentials WHERE user_id=? ORDER BY site
                """, (session['user_id'],))
                
                credentials = []
                for row in c.fetchall():
                    password = row[3]
                    strength = check_password_strength(password)
                    
                    credentials.append({
                        "id": row[0], 
                        "site": row[1], 
                        "username": row[2], 
                        "password": row[3],
                        "category": row[4],
                        "created_at": row[5],
                        "strength": strength,
                        "reused": False  # This would require more complex logic
                    })
                
                return jsonify({"success": True, "credentials": credentials})
                
        except Exception as e:
            print(f"Get credentials error: {e}")
            return jsonify({"success": False, "message": f"Failed to get credentials: {str(e)}"}), 500
    
    elif request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({"success": False, "message": "No data provided"}), 400
                
            site = data.get('site', '').strip()
            username = data.get('username', '').strip()
            password = data.get('password', '').strip()
            category = data.get('category', 'Other').strip()
            
            if not site or not username or not password:
                return jsonify({"success": False, "message": "Site, username, and password are required"}), 400
            
            with get_connection() as conn:
                c = conn.cursor()
                c.execute("""
                    INSERT INTO credentials (user_id, site, site_username, site_password, category)
                    VALUES (?, ?, ?, ?, ?)
                """, (session['user_id'], site, username, password, category))
                
                conn.commit()
                credential_id = c.lastrowid
                
                log_security_action(session['user_id'], "ADD_CREDENTIAL", f"Site: {site}")
                
                return jsonify({
                    "success": True, 
                    "message": "Credential added successfully",
                    "credential_id": credential_id
                })
                
        except Exception as e:
            print(f"Add credential error: {e}")
            return jsonify({"success": False, "message": f"Failed to add credential: {str(e)}"}), 500

@app.route('/api/credentials/<int:cred_id>', methods=['DELETE'])
def delete_credential(cred_id):
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    try:
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT site FROM credentials WHERE id=? AND user_id=?", (cred_id, session['user_id']))
            credential = c.fetchone()
            
            if not credential:
                return jsonify({"success": False, "message": "Credential not found"}), 404
            
            c.execute("DELETE FROM credentials WHERE id=?", (cred_id,))
            conn.commit()
            
            log_security_action(session['user_id'], "DELETE_CREDENTIAL", f"Site: {credential[0]}")
            
            return jsonify({"success": True, "message": "Credential deleted successfully"})
            
    except Exception as e:
        print(f"Delete credential error: {e}")
        return jsonify({"success": False, "message": f"Failed to delete credential: {str(e)}"}), 500

@app.route('/api/user/profile', methods=['GET'])
def get_user_profile():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    try:
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT email, created_at, last_login FROM users WHERE id=?", (session['user_id'],))
            user = c.fetchone()
            
            if not user:
                return jsonify({"success": False, "message": "User not found"}), 404
            
            return jsonify({
                "success": True,
                "profile": {
                    "email": user[0],
                    "created_at": user[1],
                    "last_login": user[2]
                }
            })
    except Exception as e:
        print(f"Get profile error: {e}")
        return jsonify({"success": False, "message": f"Failed to get profile: {str(e)}"}), 500

@app.route('/api/security-logs', methods=['GET'])
def get_security_logs():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    try:
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("""
                SELECT action, details, created_at, ip_address
                FROM security_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 20
            """, (session['user_id'],))
            
            logs = [{
                "action": row[0],
                "details": row[1],
                "created_at": row[2],
                "ip_address": row[3]
            } for row in c.fetchall()]
            
            return jsonify({"success": True, "logs": logs})
    except Exception as e:
        print(f"Get security logs error: {e}")
        return jsonify({"success": False, "message": f"Failed to get security logs: {str(e)}"}), 500

@app.route('/api/change-password', methods=['POST'])
def change_password():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "message": "No data provided"}), 400
            
        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')
        confirm_password = data.get('confirm_password', '')
        
        if not current_password or not new_password:
            return jsonify({"success": False, "message": "Both current and new password are required"}), 400
        
        if new_password != confirm_password:
            return jsonify({"success": False, "message": "New passwords do not match"}), 400
        
        with get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT password_hash FROM users WHERE id=?", (session['user_id'],))
            user = c.fetchone()
            
            if not user or not user[0]:
                return jsonify({"success": False, "message": "Password login not set up"}), 401
            
            if not check_password_hash(user[0], current_password):
                return jsonify({"success": False, "message": "Current password is incorrect"}), 401
            
            new_strength = check_password_strength(new_password)
            if new_strength in ['weak', 'very_weak']:
                return jsonify({"success": False, "message": "New password is too weak"}), 400
            
            new_password_hash = generate_password_hash(new_password)
            c.execute("UPDATE users SET password_hash=? WHERE id=?", (new_password_hash, session['user_id']))
            conn.commit()
            
            log_security_action(session['user_id'], "CHANGE_PASSWORD", "Password changed")
            
            return jsonify({"success": True, "message": "Password updated successfully"})
            
    except Exception as e:
        print(f"Change password error: {e}")
        return jsonify({"success": False, "message": f"Failed to change password: {str(e)}"}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    if "user_id" in session:
        log_security_action(session['user_id'], "LOGOUT", "User logged out")
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"})

# CORS support
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.before_request
def handle_preflight():
    if request.method == "OPTIONS":
        response = jsonify({"status": "success"})
        response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response

if __name__ == "__main__":
    init_db()
    print("🔒 SecureVault Password Manager with Face Recognition")
    print("🚀 Starting server on http://localhost:5000")
    print("📁 Multiple pages available:")
    print("   - /              -> Landing page")
    print("   - /login         -> Login page")
    print("   - /register      -> Registration page")
    print("   - /dashboard     -> Main dashboard")
    print("   - /passwords     -> Password management")
    print("   - /generator     -> Password generator")
    print("   - /profile       -> User profile")
    print("   - /security      -> Security settings")
    print("   - /help          -> Help & support")
    app.run(debug=True, host='0.0.0.0', port=5000)